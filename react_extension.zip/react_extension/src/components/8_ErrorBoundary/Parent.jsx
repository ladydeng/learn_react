import React, { Component } from 'react'
import Child from "./Child"

export default class Parent extends Component {
    state = { hasError:"" }  //用于标识组件是否产生错误

    // 当Parent的子组件出现报错时，会触发这个函数，并携带错误信息
    static getDerivedStateFromError(err){
        console.log(err)
        return { hasError: err }
    }

    // 渲染子组件出错时调用
    componentDidCatch(){
        // 此处统计错误，发送给后台，通知编码人员修复bug
    }

    render() {
        return (
            <div className="parent">
                <h1>parent</h1>
                { this.state.hasError? <h3>当前网络不稳定，请稍后再试</h3>: <Child/> }
            </div>
        )
    }
}
