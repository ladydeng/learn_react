// 引入常量
import { ADD_PERSON } from "../action_types"

export const addPerson = personObj => ({type:ADD_PERSON, data:personObj})