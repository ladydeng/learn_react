// 配置跨域请求代理文件，要求使用commonjs方式
const proxy = require("http-proxy-middleware")

module.exports = function(app){
    app.use(
        proxy("/api",{
            target:"http://localhost:5000",
            changeOrigin:true,
            pathRewrite:{"^/api":""}
        })
    )
}