/**
 * 该文件为Count组件定义action对象
 */
import { INCREMENT, DECREMENT } from "../action_types"

export const increment = data => ({ type: INCREMENT, data })
export const decrement = data => ({ type: DECREMENT, data })

// 异步action不是必须要用的
export const incrementAsync = (data, time = 500) => {
    // 这里的参数dispatch：由于组件Count的store.dispatch会判断传入的是对象还是函数，如果是函数的话会给这个函数传入一个参数dispatch
    return (dispatch) => {
        setTimeout(() => {
            dispatch(increment(data))
        }, time)
    }
}