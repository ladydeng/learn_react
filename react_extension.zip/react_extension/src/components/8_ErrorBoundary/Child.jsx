import React, { Component } from 'react'
import "./index.css"

export default class Child extends Component {
    state = {
        // users: [
        //     { id: "001", name: "lili", age: 18 },
        //     { id: "002", name: "lilei", age: 19 },
        //     { id: "003", name: "hmm", age: 20 }
        // ]
        
        users: "abc"
    }

    render() {
        const { users } = this.state
        return (
            <div className="child">
                <h1>child</h1>
                <ul>
                    {
                        users.map(userObj => {
                            return (
                                <li key={userObj.id}> {userObj.name} --- {userObj.age} </li>
                            )
                        })
                    }
                </ul>
            </div>
        )
    }
}
