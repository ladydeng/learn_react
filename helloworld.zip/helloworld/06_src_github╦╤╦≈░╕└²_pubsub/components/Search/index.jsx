import React, { Component } from 'react'
import axios from "axios"
import PubSub from "pubsub-js"

export default class Search extends Component {
    search = () => {
        // PubSub.publish('updateApp', { first: false, loading: true });
        // 获取用户的输入（连续解构赋值+重命名）
        const { inputNode: { value: keyWord } } = this
        if (keyWord) {
            // this.props.updateApp({ first: false, loading: true })
            PubSub.publish('updateApp', { first: false, loading: true });
            axios.get(`https://api.github.com/search/users?q=${keyWord}`).then(res => {
                // this.props.updateApp({ loading: false, listArr: res.data.items, err: null })
                PubSub.publish('updateApp', { loading: false, listArr: res.data.items, err: null });
            }).catch(err => {
                // this.props.updateApp({ loading: false, err: err.message })
                PubSub.publish('updateApp', { loading: false, err: err.message });
            })

        }
    }

    render() {
        return (
            <section className="jumbotron">
                <h3 className="jumbotron-heading">Search Github Users</h3>
                <div>
                    <input ref={e => this.inputNode = e} type="text" placeholder="enter the name you search" />
                    <button onClick={this.search}>Search</button>
                </div>
            </section>
        )
    }
}
