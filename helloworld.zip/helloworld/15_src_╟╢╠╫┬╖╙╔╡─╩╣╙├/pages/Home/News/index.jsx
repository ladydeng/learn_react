import React, { Component } from 'react'

export default class News extends Component {
    render() {
        return (
            <div>
                <ul>
                    <li>这是news内容1</li>
                    <li>这是news内容2</li>
                    <li>这是news内容3</li>
                    <li>这是news内容4</li>
                    <li>这是news内容5</li>
                </ul>
            </div>
        )
    }
}
