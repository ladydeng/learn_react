## react脚手架

### 1.全局安装：npm install -g create-react-app

### 2.创建项目：create-react-app helloworld

### 3.启动项目： npm start

### 推荐react与yarn配合使用

## yran的安装：npm install -g yarn

### 查看yarn版本：yarn --version

## 启动项目：yarn start 