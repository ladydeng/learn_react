import React, { Component } from 'react'
import "./index.css"

export default class Footer extends Component {
    handleCheckAll = (e) => {
        this.props.checkAllTodo(e.target.checked)
    }

    handleDelete = () => {
        if(window.confirm("是否要删除所有已完成的任务？")){
            this.props.deleteDoneTodo()
        }
    }

    render() {
        const { todos } = this.props

        const length = todos.length
        /**
         * reduce 方法
         * @params pre 前一项求和的值
         * @params cur 当前数组元素
         * @params index 当前元素的索引值
         * @params arr 当前操作的数组
         */
        const doneCount = todos.reduce((pre, cur, index, arr) => pre + (cur.done ? 1 : 0), 0)



        return (
            <div className="footer">
                <input type="checkbox" checked={doneCount === length && length !== 0 ? true : false} onChange={this.handleCheckAll}/>
                <p>已完成{doneCount}/全部{length}</p>
                <button className="delete" onClick={this.handleDelete}>清除已完成任务</button>
            </div>
        )
    }
}
