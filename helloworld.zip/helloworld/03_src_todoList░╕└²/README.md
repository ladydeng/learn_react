## yarn add prop-types 安装prop限制库

## yarn add nanoid 生成唯一标识