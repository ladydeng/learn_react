import React, { Component } from 'react'

export default class Loading extends Component {
    render() {
        return (
            <div>
                <p>正在加载中...</p>
            </div>
        )
    }
}
