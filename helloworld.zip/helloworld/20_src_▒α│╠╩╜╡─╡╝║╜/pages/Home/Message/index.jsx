import React, { Component } from 'react'
import { Route, Link, Redirect } from "react-router-dom"

import Detail from "./Detail"

export default class Message extends Component {
    state = {
        messageArr: [
            { id: "001", title: "message01" },
            { id: "002", title: "message02" },
            { id: "003", title: "message03" }

        ]
    }

    pushShow = (id, title) => {
        // push路由跳转
        // this.props.history.push(`/home/message/detail/${id}/${title}`)

        // this.props.history.push(`/home/message/detail/?id=${id}&title=${title}`)

        this.props.history.push("/home/message/detail", {id, title})
        
    }

    replaceShow = (id, title) => {
        // replace路由跳转
        // this.props.history.replace(`/home/message/detail/${id}/${title}`)

        // this.props.history.replace(`/home/message/detail/?id=${id}&title=${title}`)

        this.props.history.replace("/home/message/detail", {id, title})



    }

    goForward = () => {
        this.props.history.goForward()
    }

    goBack = () => {
        this.props.history.goBack()
    }

    go = () => {
        this.props.history.go(2)
    }

    render() {
        const { messageArr } = this.state
        return (
            <div>
                <ul>
                    {
                        messageArr.map(item => {
                            return (
                                <li key={item.id}>
                                    {/* 1. 向路由组件传递params参数 */}
                                    {/* <Link to={`/home/message/detail/${item.id}/${item.title}`}>{item.title}</Link> */}

                                    {/* 2. 向路由组件传递search参数 */}
                                    {/* <Link to={`/home/message/detail/?id=${item.id}&title=${item.title}`}>{item.title}</Link> */}

                                    {/* 3. 向路由组件传递state参数 */}
                                    {/* repalce 开启无痕模式 */}
                                    <Link to={{ pathname:"/home/message/detail", state:{id: item.id, title: item.title} }}>{item.title}</Link>

                                    &nbsp; &nbsp;
                                    <button onClick={() => this.pushShow(item.id, item.title)}>push跳转</button>
                                    &nbsp;&nbsp;
                                    <button onClick={() => this.replaceShow(item.id, item.title)}>replace跳转</button>
                                </li>
                            )
                        })
                    }
                </ul>
                <hr />
                {/* 1. 声明接收params参数 */}
                {/* <Route path="/home/message/detail/:id/:title" component={Detail}/> */}
                {/* <Redirect to={`/home/message/detail/${messageArr[0].id}/${messageArr[0].title}`}/> */}

                {/* 2. search无需声明接收，正常注册路由即可 */}
                {/* <Route path="/home/message/detail" component={Detail}/> */}

                {/* 3. state参数无需声明接收， 正常注册路由即可 */}
                <Route path="/home/message/detail" component={Detail}/>
 
                <hr />
                <button onClick={this.goForward}>前进</button>
                <button onClick={this.goBack}>后退</button>
                <button onClick={this.go}>前进2</button>
            </div>
        )
    }
}
