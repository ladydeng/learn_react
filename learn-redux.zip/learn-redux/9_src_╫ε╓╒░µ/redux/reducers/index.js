// 引入createStore，专门用于创建redux中最为核心的store对象
import { combineReducers } from "redux"

// 引入为Count组件服务端reducer
import count from "./count"
// 引入为Person组件服务的reducer
import persons from "./person"

// allReducer
export default combineReducers({ count, persons })