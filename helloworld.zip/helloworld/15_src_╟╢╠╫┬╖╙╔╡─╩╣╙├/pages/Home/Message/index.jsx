import React, { Component } from 'react'

export default class Message extends Component {
    render() {
        return (
            <div>
                <ul>
                    <li>这是message内容1</li>
                    <li>这是message内容2</li>
                    <li>这是message内容3</li>
                    <li>这是message内容4</li>
                    <li>这是message内容5</li>
                </ul>
            </div>
        )
    }
}
