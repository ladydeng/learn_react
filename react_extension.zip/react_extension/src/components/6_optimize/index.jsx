import React, { PureComponent } from 'react'
import "./index.css"

/* 
  PureComponent组件的使用
  1. 避免不必要的render，提升页面性能
*/


export default class Parent extends PureComponent {
    state = { carName: "奔驰" }

    changeCar = () => {
        this.setState({ carName: "奥拓" })
    }


    render() {
        console.log("parent render")
        return (
            <div className="parent">
                <h1>我是parent组件</h1>
                <p>我的车的名字是：{this.state.carName}</p>
                <button onClick={this.changeCar}>点我换车</button>
                <Child />
            </div>
        )
    }
}

class Child extends PureComponent {
    render() {
        console.log("child render")
        return (
            <div className="child">
                <h1>我是child组件</h1>
            </div>
        )
    }
}

