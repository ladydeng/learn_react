import React, { Component } from "react"
import "./index.less"
import sum from "./utiles"

export default class Hello extends Component {
    render(){
        return (
            <div className="hello">
                <h2 className="title"> Hello React! { sum() }</h2>
            </div>
        )
    }
}