import React, { Component } from 'react'
import { connect } from "react-redux"
import { nanoid } from "nanoid"

import { createAddPersonAction } from "../../redux/actions/person"

class Person extends Component {
    addPerson = () => {
        const name = this.nameNode.value
        const age = this.ageNode.value
        const personObj = { id: nanoid(),name,age}
        // 使用父组件传递的函数addPerson添加人
        this.props.jia(personObj)
        // 清空输入框
        this.nameNode.value = ""
        this.ageNode.value = ""
    }

    render() {
        console.log(this.props.persons)
        return (
            <div>
                <h1>Person组件</h1>
                <input type="text" ref={e => this.nameNode = e} placeholder="请输入姓名" />
                <input type="text" ref={e => this.ageNode = e} placeholder="请输入年龄" />
                <br />
                <br />
                <button onClick={this.addPerson}>添加+1</button>
                <ul>
                    {
                        this.props.persons.map(person => {
                            return <li key={ person.id }>{ person.name }---------{ person.age }</li>
                        })
                    }
                </ul>
            </div>
        )
    }
}

export default connect(
    state => ({ persons: state.persons }),
    {
        jia:createAddPersonAction
    }
)(Person)
