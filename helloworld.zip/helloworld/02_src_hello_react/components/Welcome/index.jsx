import React, { Component } from "react"
import "./index.less"

export default class Welcome extends Component {
    render(){
        return (
            <div className="welcome">
                <h2>welcome</h2>
            </div>
        )
    }
}