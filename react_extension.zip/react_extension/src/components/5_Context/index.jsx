// 实际开发中一般不用context，用react-redux

import React, { Component, createContext } from 'react'
import "./index.css"

// 创建context容器,用于祖孙组件之间的通信
const UserNameContext = createContext()
// 拿到Provider组件
const { Provider, Consumer } = UserNameContext

export default class A extends Component {
    state = { userName: "lili", userAge: 18 }

    render() {
        const { userName, userAge } = this.state
        return (
            <div className="a">
                <h1>A组件</h1>
                <p>我的用户名是：{userName}</p>
                {/* 给B组件及其后代组件传值，value=你要传的值 */}
                <Provider value={{ userName, userAge }}>
                    <B />
                </Provider>
            </div>
        )
    }
}

class B extends Component {
    render() {
        return (
            <div className="b">
                <h1>B组件</h1>
                <C />
            </div>
        )
    }
}

/* class C extends Component {
    // 声明接收context,这种接收方法仅适用于类组件
    static contextType = UserNameContext

    render() {
        // this.context获取祖组件传递的参数
        const { userName, userAge } = this.context
        return (
            <div className="c">
                <h1>C组件</h1>
                <p>接收到A组件的参数是：{userName},{ userAge}</p>
            </div>
        )
    }
} */

function C() {
    return (
        <div className="c">
            <h1>C组件</h1>
            <p>接收到A组件的参数是：
                <Consumer>
                    {
                        value => {
                            return `${ value.userName }，年龄是：${ value.userAge }`
                        }
                    }
                </Consumer>
            </p>
        </div>
    )
}

