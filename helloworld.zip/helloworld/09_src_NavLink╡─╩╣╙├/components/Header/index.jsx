import React, { Component } from 'react'

export default class Header extends Component {
    render() {
        return (
            <div>
                <div className="page-header"><h2>react router demo</h2></div>
            </div>
        )
    }
}
