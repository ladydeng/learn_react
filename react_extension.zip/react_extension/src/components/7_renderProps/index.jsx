import React, { Component } from 'react'
import "./index.css"

export default class Parent extends Component {
    render() {
        return (
            <div className="parent">
                <h1>我是Parent组件</h1>
                {/* <A>
                    <B/>
                </A> */}

                {/* 解决A组件给B组件传值的问题 */}
                {/* 往插槽里放内容 */}
                <A render={(name) => <B name={name} />} />
            </div>
        )
    }
}

class A extends Component {
    state = { name: "lili" }
    render() {
        const { name } = this.state
        return (
            <div className="a">
                <h1>我是A组件</h1>
                {/* { this.props.children } */}
                
                {/* 解决A组件给B组件传值的问题，这里相当于vue里的预留位置的插槽this.props.render() */}
                {this.props.render(name)}
            </div>
        )
    }
}


class B extends Component {
    render() {
        return (
            <div className="b">
                <h1>我是B组件:{this.props.name}</h1>
            </div>
        )
    }
}

