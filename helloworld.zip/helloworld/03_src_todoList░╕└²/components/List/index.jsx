import React, { Component } from 'react'
import PropTypes from "prop-types"
import ListItem from "../ListItem"
import "./index.css"

export default class List extends Component {
    // 对props进行类型以及必要性限制
    static propTypes = {
        todos: PropTypes.array.isRequired,
        updateTodo: PropTypes.func.isRequired,
        deleteTodo: PropTypes.func.isRequired
    }

    render() {
        const { todos, updateTodo, deleteTodo } = this.props
        return (
            <div className="list">
                <ul>
                   {
                        todos.map(todo => {
                            return <ListItem key={todo.id} {...todo} updateTodo={ updateTodo } deleteTodo={deleteTodo}/>
                        })
                   }
                </ul>
            </div>
        )
    }
}