# yarn add react-router-dom 安装路由
## querystring库是react的内置库，它有两个方法
   1. querystring.parse() 将一个字符串转为对象
   2. querystring.stringfy（）将一个对象转为字符串