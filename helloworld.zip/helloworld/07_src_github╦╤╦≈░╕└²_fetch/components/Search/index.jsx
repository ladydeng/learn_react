import React, { Component } from 'react'
// import axios from "axios"
import PubSub from "pubsub-js"

export default class Search extends Component {
    search = async () => {
        // 获取用户的输入（连续解构赋值+重命名）
        const { inputNode: { value: keyWord } } = this
        if (keyWord) {
            PubSub.publish('updateApp', { first: false, loading: true });
            //#region 使用axios发送网络请求
            /*  axios.get(`https://api.github.com/search/users?q=${keyWord}`).then(res => {
                 PubSub.publish('updateApp', { loading: false, listArr: res.data.items, err: null });
             }).catch(err => {
                 PubSub.publish('updateApp', { loading: false, err: err.message });
             }) */
            //#endregion

            //#region  使用fetch发送网络请求（未优化）--react内置有fetch
            /* fetch(`https://api.github.com/search/users?q=${keyWord}`).then(
                // 联系服务器成功了，调用res的json方法（返回一个带有结果的promise）
                res => { return res.json() },
            ).then(
                // 获取数据成功了
                res => { PubSub.publish('updateApp', { loading: false, listArr: res.items, err: null }); },
            ).catch(
                // 出错了
                err => { console.log(err); PubSub.publish('updateApp', { loading: false, err: err.message });}
            ) */
            //#endregion

            // 使用fetch发送请求（优化）async和两个await接收请求结果（await只会接收请求成功的信息）
            try {
                const res = await fetch(`https://api.github.com/search/users?q=${keyWord}`)
                const data = await res.json()
                PubSub.publish('updateApp', { loading: false, listArr: data.items, err: null });
            } catch (err) {
                PubSub.publish('updateApp', { loading: false, err: err.message });
            }
        }
    }

    render() {
        return (
            <section className="jumbotron">
                <h3 className="jumbotron-heading">Search Github Users</h3>
                <div>
                    <input ref={e => this.inputNode = e} type="text" placeholder="enter the name you search" />
                    <button onClick={this.search}>Search</button>
                </div>
            </section>
        )
    }
}
