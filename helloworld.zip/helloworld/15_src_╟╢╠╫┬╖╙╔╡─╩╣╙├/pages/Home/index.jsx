import React, { Component } from 'react'
import { Route, Switch, Redirect } from 'react-router-dom'

import MyNavLink from '../../components/MyNavLink'
import News from "../Home/News"
import Message from "../Home/Message"

export default class Home extends Component {
    render() {
        return (
            <div>
                <h3>我是Home里面的内容</h3>
                <ul className="nav nav-tabs">
                    <li>
                        <MyNavLink to="/home/news">news</MyNavLink>
                    </li>
                    <li>
                        <MyNavLink to="/home/message">message</MyNavLink>
                    </li>
                </ul>
                <div>
                    {/* 注册路由 */}
                    <Switch>
                        <Route path="/home/news" component={News} />
                        <Route path="/home/message" component={Message} />
                        <Redirect to="/home/news"/>
                    </Switch>
                </div>
            </div>
        )
    }
}
