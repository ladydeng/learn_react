import React, { Component } from 'react'
import Search from "./components/Search"
import List from "./components/List"

export default class App extends Component {
    state = {
        listArr: [],
        first: true,
        loading: false,
        err: null
    }

    updateApp = (res) => {
        this.setState(res)
    }


    render() {
        return (
            <div className="container">
                <Search updateApp={this.updateApp} />
                <List {...this.state} />
            </div>
        )
    }
}
