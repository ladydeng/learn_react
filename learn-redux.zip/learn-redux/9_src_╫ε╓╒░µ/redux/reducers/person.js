import { ADD_PERSON } from "../action_types"

// 给state一个默认值
const defaultState = [{ id: "01", name: "lili", age: 18 }]
// 该文件用于初始化状态和加工状态
export default function persons(preState = defaultState, action) {
    const { type, data } = action
    switch (type) {
        case ADD_PERSON:
            // 若原来的preState地址与return回去的值的地址一致，则页面不会更新
            // return preState.unshift(data)   //页面不更新
            return [ data, ...preState ] //改变state
            break;
        default:
            return preState
    }
}