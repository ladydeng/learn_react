/**
 * 该文件为Count组件定义action对象
 */
import { INCREMENT, DECREMENT } from "./action_types"

export const createIncrementAction = data => ({ type: INCREMENT, data })
export const createDecrementAction = data => ({ type: DECREMENT, data })

// 异步action不是必须要用的
export const createIncrementAsyncAction = (data, time = 500) => {
    // 这里的参数dispatch：由于组件Count的store.dispatch会判断传入的是对象还是函数，如果是函数的话会给这个函数传入一个参数dispatch
    return (dispatch) => {
        setTimeout(() => {
            dispatch(createIncrementAction(data))
        }, time)
    }
}