// 引入react核心库
import React from "react"
// 引入react-dom
import ReactDom from "react-dom"
// 引入App组件
import App from "./App"

// 渲染组件到DOM
ReactDom.render(<App/>, document.getElementById("app"))

