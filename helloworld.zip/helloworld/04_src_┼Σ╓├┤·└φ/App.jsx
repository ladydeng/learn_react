import React, { Component } from 'react'
import axios from "axios"

export default class App extends Component {
    getData = () => {
        axios.get("http://localhost:3000/api/findsofa")
            .then(res => {
                console.log(res)
            })
            .catch(err => {
                console.log("请求失败")
            })
    }

    render() {
        return (
            <div>
                <button onClick={this.getData}>获取数据</button>
            </div>
        )
    }
}
