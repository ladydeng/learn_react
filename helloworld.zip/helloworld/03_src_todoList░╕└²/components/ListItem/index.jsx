import React, { Component } from 'react'
import "./index.css"

export default class ListItem extends Component {
    state = { mouse: false }

    handleMouse = (bool) => {
        // const { mouse } = this.state
        return () => {
            this.setState({ mouse: bool })
        }
    }

    changeCheck = id => {
        return e => {
            this.props.updateTodo(id, e.target.checked)
        }
    }

    handleDelete = (id) => {
        if(window.confirm("你确定删除吗？")){
            this.props.deleteTodo(id)
        }
    }


    render() {
        const { id, name, done } = this.props
        const { mouse } = this.state
        return (
            <li className="list-item" style={{ background: mouse ? "rgb(231, 231, 231)" : "white" }} onMouseEnter={this.handleMouse(true)} onMouseLeave={this.handleMouse(false)}>
                <input type="checkbox" checked={done} onChange={this.changeCheck(id)} />
                <span>{name}</span>
                <button className="delete" style={{ display: mouse ? "block" : "none" }} onClick={() => { this.handleDelete(id) }}>删除</button>
            </li>
        )
    }
}
