import React, { Component } from 'react'
import Header from "./components/Header"
import List from "./components/List"
import Footer from "./components/Footer"
import "./index.css"

export default class App extends Component {
    state = {
        todos: [
            { id: "001", name: "hmm", done: true },
            { id: "002", name: "lilei", done: true },
            { id: "003", name: "张三", done: false },
            { id: "004", name: "李四", done: true }
        ],
    }

    addTodo = (obj) => {
        // 获取原数组
        const { todos } = this.state
        // 把获取的obj添加到todos
        this.setState({ todos: [obj, ...todos] })

    }

    updateTodo = (id, done) => {
        const { todos } = this.state
        var newTodos = todos.map(todo => {
            if (todo.id === id) return { ...todo, done }
            else return todo
        })
        this.setState({ todos: newTodos })
    }

    deleteTodo = (id) => {
        const { todos } = this.state
        const newTodos = todos.filter(todo => {
            return todo.id !== id
        })
        this.setState({ todos: newTodos })
    }

    checkAllTodo = (done) => {
        const { todos } = this.state
        const newTodos = todos.map(todo => {
            return {...todo, done}
        })
        this.setState({ todos: newTodos })
    }

    deleteDoneTodo = () => {
        const { todos } = this.state
        const newTodos = todos.filter(todo => {
            return todo.done === false
        }) 
        this.setState({ todos: newTodos })
    }

    render() {
        const { todos } = this.state
        return (
            <div className="wrapper">
                {/*todos={[...todos]}、todos={todos}两种方式传参结果一样*/}
                <Header addTodo={this.addTodo} />
                <List todos={[...todos]} updateTodo={this.updateTodo} deleteTodo={this.deleteTodo}/>
                <Footer todos={todos} checkAllTodo={this.checkAllTodo} deleteDoneTodo={this.deleteDoneTodo}/>
            </div>
        )
    }
}
