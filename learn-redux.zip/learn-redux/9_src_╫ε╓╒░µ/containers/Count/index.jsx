import React, { Component } from 'react'
// 引入connect用于连接UI组件与redux
import { connect } from "react-redux"
// 引入action 
import { increment, decrement, incrementAsync } from "../../redux/actions/count"

class Count extends Component {
    increment = () => {
        const { value } = this.selectDOM
        this.props.increment(value * 1)
    }

    decrement = () => {
        const { value } = this.selectDOM
        this.props.decrement(value * 1)
    }

    incrementIfOdd = () => {
        const { value } = this.selectDOM
        const count = this.props.count
        if ((count % 2) !== 0) {
            this.props.increment(value * 1)
        }
    }

    incrementAsync = () => {
        const { value } = this.selectDOM
        this.props.incrementAsync(value * 1)
    }

    render() {
        return (
            <div>
                <h1>Count组件,下面的Person组件的总人数为：{this.props.sum}</h1>
                <h1>当前求和为：{this.props.count}</h1>
                <select ref={e => this.selectDOM = e}>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                </select>&nbsp;
                <button onClick={this.increment}>+</button>&nbsp;
                <button onClick={this.decrement}>-</button>&nbsp;
                <button onClick={this.incrementIfOdd}>求合为基数时+</button>&nbsp;
                <button onClick={this.incrementAsync}>异步+</button>
            </div>
        )
    }
}


// 使用connect()()创建并暴露一个Count的容器组件，并且会检测state变化更新页面
export default connect(
    state => ({ count: state.count, sum: state.persons.length }),
    // mapDispatchToProps的简写--- react-redux的优化写法
    {
        increment,
        decrement,
        incrementAsync
    }
)(Count)