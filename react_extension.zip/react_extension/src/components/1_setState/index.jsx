import React, { Component } from 'react'

export default class Demo extends Component {
    state = { count: 0 }

    add = () => {
        const { count } = this.state
        // setState的两种写法，setState更新状态的动作是异步的
        // 1.对象式的setState
        /* this.setState({ count: count + 1 }, () => {
            console.log("箭头函数内部：",this.state.count) // 1
        })
        console.log("箭头函数外部：",this.state.count) */  // 0

        // 2.函数式的setState
        this.setState((state, props) => {
            console.log(state, props)
            return { count: count + 1 }
        },() => {
            console.log("修改完状态后执行的函数",this.state.count)
        })
    }

    render() {
        return (
            <div>
                <h1>当前求和为：{this.state.count}</h1>
                <button onClick={this.add}>点击+1</button>
            </div>
        )
    }
}
