import React, { Component } from 'react'
// import qs from "querystring"

export default class Detail extends Component {
    state = {
        contentArr: [
            { id: "001", content: "hello vue" },
            { id: "002", content: "hello react" },
            { id: "003", content: "hello angular" }
        ]
    }
    render() {
        // 1. 接收路由参数params
        // const { id, title } = this.props.match.params

        // 2. 接收search参数
        // const { search } = this.props.location
        // 使用qs库转换参数
        // const { id, title } = qs.parse(search.slice(1))

 
        // 3. 接收路由参数state,加上条||解决页面刷新参数丢失问题
        const { id, title } = this.props.location.state || {}




        const { contentArr } = this.state
        const obj = contentArr.find(item => {
            return item.id === id
        }) || {}
        return (
            <div>
                <p>id: {id}</p>
                <p>title: {title}</p>
                <p>content: {obj.content}</p>
            </div>
        )
    }
}
