/* 
  自定义UI组件与容器组件结合文件步骤
  （1）自定义UI组件
  （2）引入connect为该UI组件创建一个容器组件
   (3) 给UI组件传递状态和操作状态的方法--操作状态的方法可以写成对象形式，react-redux内部会自动形成对应的映射关系
*/

import React, { Component } from 'react'
import { connect } from "react-redux"
import { createIncrementAction } from "../../redux/count_action"

class Count extends Component {
    add = () => {
        this.props.jia(1)
    }

    render() {
        return (
            <div>
                <p>求和为：{this.props.num}</p>
                <button onClick={this.add}>点击+1</button>
            </div>
        )
    }
}

export default connect(
    state => ({ num: state }),
    {
        jia: createIncrementAction
    }
)(Count)
