import React, { Component } from 'react'
import Demo from "./components/8_ErrorBoundary/Parent"

export default class App extends Component {
    render() {
        return (
            <div name="lili">
               <Demo val="2"/> 
            </div>
        )
    }
}
