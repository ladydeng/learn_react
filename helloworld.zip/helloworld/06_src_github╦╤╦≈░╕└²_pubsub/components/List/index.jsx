import React, { Component } from 'react'
import PubSub from "pubsub-js"
import "./index.css"

export default class List extends Component {
    state = {
        listArr: [],
        first: true,
        loading: false,
        err: null
    }

    updateApp = (msg, data) => {
        this.setState(data)
    }

    componentDidMount() {
        this.token = PubSub.subscribe('updateApp', this.updateApp);
    }

    componentWillUnmount(){
        PubSub.unsubscribe(this.token);
    }

    render() {
        const { listArr, first, loading, err } = this.state
        if (first === true) return <div>请输入name关键字搜索</div>
        if (loading === true) return <div>正在加载中</div>
        if (err) return <div>{err}</div>
        return (
            <div className="row">
                {
                    listArr.map(item => {
                        return (
                            <div className="card" key={item.id}>
                                <a rel="noreferrer" href={item.html_url} target="_blank">
                                    <img alt="head_portrait" src={item.avatar_url} style={{ width: "100px" }} />
                                </a>
                                <p className="card-text">{item.login}</p>
                            </div>
                        )
                    })
                }
            </div>
        )
    }
}
