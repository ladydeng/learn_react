import React, { Component } from 'react'
import "./index.css"

export default class List extends Component {
    render() {
        const { listArr, first, loading, err } = this.props
        if (first === true) return <div>请输入name关键字搜索</div>
        if (loading === true) return <div>正在加载中</div>
        if (err) return <div>{err}</div>
        return (
            <div className="row">
                {
                    listArr.map(item => {
                        return (
                            <div className="card" key={item.id}>
                                <a rel="noreferrer" href={item.html_url} target="_blank">
                                    <img alt="head_portrait" src={item.avatar_url} style={{ width: "100px" }} />
                                </a>
                                <p className="card-text">{item.login}</p>
                            </div>
                        )
                    })
                }
            </div>
        )
    }
}
