import React, { Component } from 'react'
import { Route, Link, Redirect } from "react-router-dom"

import Detail from "./Detail"

export default class Message extends Component {
    state = {
        messageArr: [
            { id: "001", title: "message01" },
            { id: "002", title: "message02" },
            { id: "003", title: "message03" }

        ]
    }
    render() {
        const { messageArr } = this.state
        return (
            <div>
                <ul>
                    {
                        messageArr.map(item => {
                            return (
                                <li key={item.id}>
                                    {/* 1. 向路由组件传递params参数 */}
                                    {/* <Link to={`/home/message/detail/${item.id}/${item.title}`}>{item.title}</Link> */}

                                    {/* 2. 向路由组件传递search参数 */}
                                    {/* <Link to={`/home/message/detail/?id=${item.id}&title=${item.title}`}>{item.title}</Link> */}

                                    {/* 3. 向路由组件传递state参数 */}
                                    {/* repalce 开启无痕模式 */}
                                    <Link replace to={{ pathname:"/home/message/detail", state:{id: item.id, title: item.title} }}>{item.title}</Link>
                                </li>
                            )
                        })
                    }
                </ul>
                <hr />
                {/* 1. 声明接收params参数 */}
                {/* <Route path="/home/message/detail/:id/:title" component={Detail}/> */}
                {/* <Redirect to={`/home/message/detail/${messageArr[0].id}/${messageArr[0].title}`}/> */}

                {/* 2. search无需声明接收，正常注册路由即可 */}
                {/* <Route path="/home/message/detail" component={Detail}/> */}

                {/* 3. state参数无需声明接收， 正常注册路由即可 */}
                <Route path="/home/message/detail" component={Detail}/>
            </div>
        )
    }
}
