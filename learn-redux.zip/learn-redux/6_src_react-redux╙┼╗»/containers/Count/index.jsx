import React, { Component } from 'react'
// 引入connect用于连接UI组件与redux
import { connect } from "react-redux"
// 引入action 
import { createIncrementAction, createDecrementAction, createIncrementAsyncAction } from "../../redux/count_action"

class Count extends Component {
    increment = () => {
        const { value } = this.selectDOM
        this.props.jia(value * 1)
    }

    decrement = () => {
        const { value } = this.selectDOM
        this.props.jian(value * 1)
    }

    incrementIfOdd = () => {
        const { value } = this.selectDOM
        const count = this.props.count
        if ((count % 2) !== 0) {
            this.props.jia(value * 1)
        }
    }

    incrementAsync = () => {
        const { value } = this.selectDOM
        this.props.asyncJia(value * 1)
    }

    render() {
        return (
            <div>
                <h1>当前求和为：{this.props.count}</h1>
                <select ref={e => this.selectDOM = e}>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                </select>&nbsp;
                <button onClick={this.increment}>+</button>&nbsp;
                <button onClick={this.decrement}>-</button>&nbsp;
                <button onClick={this.incrementIfOdd}>求合为基数时+</button>&nbsp;
                <button onClick={this.incrementAsync}>异步+</button>
            </div>
        )
    }
}


// 使用connect()()创建并暴露一个Count的容器组件，并且会检测state变化更新页面
export default connect(
    state => ({ count: state }),
    // mapDispatchToProps的一般写法
    /* dispatch => ({
        jia: (data) => dispatch(createIncrementAction(data)),
        jian: (data) => dispatch(createDecrementAction(data)),
        asyncJia: (data, time) => dispatch(createIncrementAsyncAction(data, time))
    }) */

    // mapDispatchToProps的简写--- react-redux的优化写法
    {
        jia: createIncrementAction,
        jian: createDecrementAction,
        asyncJia: createIncrementAsyncAction
    }
)(Count)