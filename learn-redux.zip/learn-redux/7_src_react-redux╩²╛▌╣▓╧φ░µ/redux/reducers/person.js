import { ADD_PERSON } from "../action_types"

// 给state一个默认值
const defaultState = [{ id: "01", name: "lili", age: 18 }]
// 该文件用于初始化状态和加工状态
export default function personReducer(preState = defaultState, action) {
    const { type, data } = action
    switch (type) {
        case ADD_PERSON:
            return [ data, ...preState ] //改变state
            break;
        default:
            return preState
    }
}