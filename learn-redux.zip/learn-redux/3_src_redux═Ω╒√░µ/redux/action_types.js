/**
 * 该模块用于定义action对象中type类型的常量值（便于后期项目维护）
 */
export const INCREMENT = "increment";
export const DECREMENT = "decrement"