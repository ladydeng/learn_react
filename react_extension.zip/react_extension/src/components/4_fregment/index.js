import React, { Component, Fragment } from 'react'

export default class Demo extends Component {
    render() {
        return (
            // 相当于一个空标签，但是可以并且只能指定key属性
            // <Fragment key='1'>
            //     <p>这是段落</p>
            // </Fragment>

            // <> </>会渲染为一个空标签，并且不能指定属性
            <>
                <p>这是段落</p>
            </>
        )
    }
}
