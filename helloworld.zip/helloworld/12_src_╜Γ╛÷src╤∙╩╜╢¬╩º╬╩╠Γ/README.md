# yarn add react-router-dom 安装路由
## 解决刷新页面之后样式丢失问题---使用绝对路或%PUBLIC_URL%或使用HashRouter