import React, { Component } from 'react'
import { Route, Switch } from "react-router-dom"

import Home from "./pages/Home"   //路由组件
import About from "./pages/About"
import Header from "./components/Header"   //一般组件
import MyNavLink from "./components/MyNavLink"

export default class App extends Component {
    render() {
        return (
            <div>
                <div className="row">
                    <div className="col-xs-offset-2 col-xs-8">
                        <Header />
                    </div>
                </div>
                <div className="row">
                    <div className="col-xs-2 col-xs-offset-2">
                        <div className="list-group">
                            {/* 原生html靠a标签跳转 */}
                            {/* <a href="#" className="list-group-item">About</a>
                            <a href="#" className="list-group-item active">Home</a> */}

                            {/* 在React中考路由链接实现切换组件 */}
                            {/* NavLink 默认活跃的样式类名为active */}
                            {/* <NavLink activeClassName="active" className="list-group-item" to="/about">About</NavLink>
                            <NavLink activeClassName="active" className="list-group-item" to="/home">Home</NavLink> */}
                            <MyNavLink to="/atguigu/about">About</MyNavLink>
                            <MyNavLink to="/atguigu/home">Home</MyNavLink>
                        </div>
                    </div>
                    <div className="col-xs-6">
                        <div className="panel">
                            <div className="panel-body">
                                {/* 注册路由时加上Switch，提高路由匹配效率（匹配一个之后就不会往下匹配了） */}
                                <Switch>
                                    <Route path="/atguigu/about" component={About} />
                                    <Route path="/atguigu/home" component={Home} />
                                </Switch>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
