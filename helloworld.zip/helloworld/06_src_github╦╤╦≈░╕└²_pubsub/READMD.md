# yarn add pubsub-js 安装pubsub用于兄弟组件的通信

# 选中之后按alt+shift+a多行注释