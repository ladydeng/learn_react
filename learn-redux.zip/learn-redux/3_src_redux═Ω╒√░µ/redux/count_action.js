/**
 * 该文件为Count组件定义action对象
 */
import { INCREMENT, DECREMENT } from "./action_types"

export const createIncrementAction = data => ({ type: INCREMENT, data })
export const createDecrementAction = data => ({ type: DECREMENT, data })