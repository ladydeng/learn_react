import React, { Component } from 'react'
// withRouter方法可以加工一般组件，使一般组件具有路由组件的API
// withRouter的返回值是一个新组件
import { withRouter } from 'react-router'

class Header extends Component {

    goForward = () => {
        this.props.history.goForward()
    }

    goBack = () => {
        this.props.history.goBack()
    }

    go = () => {
        this.props.history.go(2)
    }


    render() {
        return (
            <div>
                <div className="page-header">
                    <h2>react router demo</h2>
                    <button onClick={this.goForward}>前进</button>
                    <button onClick={this.goBack}>后退</button>
                    <button onClick={this.go}>前进2</button>
                </div>
            </div>
        )
    }
}

// 导出加工后的Header组件
export default withRouter(Header)
