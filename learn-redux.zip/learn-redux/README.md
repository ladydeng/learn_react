# yarn add redux 安装redux管理全局state

# redux异步action
  （1） 明确：延迟的动作不想交给组件自身，想交给action
  （2） 何时需要异步action：想要对状态进行操作，但是具体的数据靠异步任务返回
  （3） 具体编码：
        a. yarn add redux-thunk, 并配置在store中
        b. 创建action的函数不再返回一般对象，而是一个函数，该函数中写异步任务
        c. 异步任务有结果后，分发一个同步的action去操作真正的数据
   (4)  备注：异步action不是必须要写的，完全可以自己等待异步任务的结果再去分发同步action

# npm i serve -g  安装serve，用于指定文件夹为根目录开启服务器
  使用：(1) 直接cd进入你的文件夹，运行命令：serve
       (2)  比如我想要以该文件夹下的build目录为根目录，则: serve build