import React, { Component } from 'react'

export default class Home extends Component {
    render() {
        return (
                <h3>我是Home里面的内容</h3>
        )
    }
}
