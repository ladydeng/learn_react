# 1. yarn add redux-devtools-extension 使谷歌插件能检测到redux数据的变化
# 2. 配置store.js