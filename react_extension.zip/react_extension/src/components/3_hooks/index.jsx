import React from 'react'
import ReactDOM from "react-dom"

export default function Demo() {
    //  三大hooks：
    // 一、useState()的使用，使得函数组件也有自己的状态和更新状态的方法
    const [count, setCount] = React.useState(0)
 
    // 二、useRef()的使用，创建ref，用法与createRef一样
    const myRef = React.useRef()

    // 三、useEffect()的使用，里面传的箭头函数相当于组件的钩子函数componentDidMount，componentDidUpdate
    // 当组件挂载，count每一秒钟+1
    React.useEffect(() => {
        let timer = setInterval(() => {
            setCount(count => count + 1)
        }, 1000)

        // useEffect()里的函数返回的这个函数相当于钩子函数componentWillUnmount
        return () => {
            clearInterval(timer)
        }
    }, [])
    // 只要数组里的count改变，那么这个箭头函数就会被调用,相当于watcher

    function add() {
        // 写法1：
        // setCount(count + 1)
        // 写法2：
        setCount(count => count + 1)
    }

    function unmount(){
        ReactDOM.unmountComponentAtNode(document.getElementById("root"))
    }

    function show(){
        const { value } = myRef.current
        alert("你输入的值为："+ value)
    }

    return (
        <div>
            <h2>当前求和为：{count}</h2>
            <button onClick={add}>点击+1</button>
            <button onClick={unmount}>卸载组件</button><br />
            <input type="text" ref={myRef}/>
            <button onClick={show}>点击获取提示</button>
        </div>
    )
}
