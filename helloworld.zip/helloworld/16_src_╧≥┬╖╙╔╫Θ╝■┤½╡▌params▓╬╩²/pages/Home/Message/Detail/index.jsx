import React, { Component } from 'react'

export default class Detail extends Component {
    state = {
        contentArr: [
            { id: "001", content: "hello vue" },
            { id: "002", content: "hello react" },
            { id: "003", content: "hello angular" }
        ]
    }
    render() {
        // 接收路由参数
        const { params } = this.props.match
        const { contentArr } = this.state
        const obj = contentArr.find(item => {
            return item.id == params.id
        })
        return (
            <div>
                <p>id: {params.id}</p>
                <p>title: {params.title}</p>
                <p>content: {obj.content}</p>
            </div>
        )
    }
}
