export default function sum(){
    return 1+2
}